
package com.mycompany.main;

//Import Scanner so we can get user input
import java.util.Scanner; 

//Create the Main Class
public class Main { 
    
    //Create Scanner for the user input 
    static Scanner input = new Scanner(System.in);
    
    //Store the registered usernanme
    static String registeredUsername;
    
    //Store the registered password
    static String  registeredPassword;
    
    //Store the registered cellphone number
    static String registeredCellPhone;
    
    //Create the username checking method
    public static boolean checkUserName(String username) {
        
        //Temporary return value
        return false;
    }
    //Create the password checking method
    public static boolean checkPasswordComplexity(String password){
         
        //Temporary return value
        return false;
    }
    
    //Create the cellphone checking method
    public static boolean checkCellPhoneNumber(String number){
        
        //Temporary rreturn value
        return false;
    }
    
    //Create the registration method
    public static void registerUser(){
        
        //Registration code will be added later
    }
    
    //Create the login method
    public static boolean loginUser(String username, String password){
       
        //Temporary return value
        return false;
    }
    
     //Create the login status method
    public static String returnLoginStatus(boolean loginSuccessfully){ 
        
        //Temporary return message
        return " ";
    }
    
    //Main method where the program starts
    public static void main(String[] args) {
       
        //Calls the username method
        checkUserName("");
        
        //Calls the password method
        checkPasswordComplexity("");  
        
        //Calls the cellphone method
        checkCellPhoneNumber("");
        
        //Calls the registration method 
        registerUser();
        
        //Calls the login method
        loginUser("","");
        
        //Calls the login status method
        returnLoginStatus(false);   
    }
}
 